php ./merge.php
pause